php ./merge.php
pause